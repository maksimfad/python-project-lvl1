"""This is project for learning purposes."""
